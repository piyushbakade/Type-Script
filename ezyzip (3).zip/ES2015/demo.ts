// // ques1
// const pi = 3.14;
// console.log(pi);

// // ques2
// if (true){
//     let a=1;
// }
// // console.log(a);
// //  ques3
// var order = {
//     id : 1 ,    
//     title : "laptop",
//     price : "50k",

//     printOrder(){
//         return this.id +" "+ this.title;
//     },
//     getPrice(){
//         return this.price;
//     }
// }
// let returnedTarget = Object.assign({}, order);
// console.log(returnedTarget);

// // ques4
// class Object1{
//     name1;
//     length1;
//     constructor(name1:string){
//         this.name1 = name1;
//         this.length1 = name1.length;
//     }
// }

// let displayArray = (...objects: Array<object>) =>{
//     for(let i in objects)
//     console.log(objects[i]);
// }

// let names = ['tom', 'ivan', 'Jerry'];
// let [name1, name2, name3] = names;
// const obj1 = new Object1(name1);
// const obj2 = new Object1(name2);
// const obj3 = new Object1(name3);

// displayArray(obj1,obj2,obj3);

// // ques 5a
// var add = () => 21; 

// // ques 5b
// function userFriends(username: string, ...friends: Array<string>){
//     console.log("username: ",username);
//     console.log("friends: ",friends);
// }

// userFriends('John','Alex','Ross','Berlin','Joey','Phoebe');
// console.log("----------------------------------------------------");

// //ques 5c
// function printCapitalNames(...names: Array<string>){
//     console.log();
//     for(let i in names)
//         console.log(names[i].toUpperCase());
// }

// printCapitalNames('John','Alex','Ross','Berlin','Joey','Phoebe');
// console.log("----------------------------------------------------");

// // ques 6

// var laptop = "HP", model = "Pavillion", deskno = 123, client='Hewlett Packard';
// var ticket = `hi Sysnet, this is ${client} - deskNo.: ${deskno}, and my laptop: ${laptop}, 
// model: ${model}, isn't working. Request replacement.`;
// console.log(ticket);
// console.log("----------------------------------------------------");

// //ques 7a
// let array = [1,2,3,4];
// let [ele1, ele2, ele3, ele4] = array;
// console.log("3rd element: ",ele3);
// console.log("----------------------------------------------------");

// //ques 7b
// var organization = {
//     name: "Capgemini",
//     address: { country: "France", pincode: 75017}
// }
// let {nameObj, address: a} = organization;
// console.log("deep match destructured pincode: ",a.pincode);
// console.log("----------------------------------------------------");

// ques 8
class Account{
    constructor(id, name, balance){
        this.id = id;
        this.name = name;
        this.balance = balance;
    }

    totalBalance(){
        return this.balance;
    }
} 

class SavingAccount extends Account{
    constructor(id, name, balance, interest){
        super(id, name, balance = balance + (balance*interest)/100);
    }
}

class CurrentAccount extends Account{
    constructor(id, name, balance, cash_credit){
        super(id, name, balance = balance+cash_credit);
    }
}

let savingAccount = new SavingAccount(12, "chandler", 10000, 10);
let currentAccount = new CurrentAccount(34, "chandler", 12000, 5000);

console.log(savingAccount.totalBalance());
console.log(currentAccount.totalBalance());





